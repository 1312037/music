﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCreationalPatterns
{
    public class Marine : Unit
    {
    }
}