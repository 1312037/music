﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCreationalPatterns
{
    public class Barrack
    {
        //public Unit RecruitUnit(string strName)
        //{
        //    Unit unit = null;
        //    switch (strName)
        //    {
        //        case "Marine":
        //            unit = new Marine();
        //            break;
        //        case "Firebat":
        //            unit = new Firebat();
        //            break;
        //        case "Ghost":
        //            unit = new Ghost();
        //            break;
        //    }
        //    return unit;
        //}

        /*        public Unit RecruitUnit(string strName)
                {
                    Unit unit = null;
                    switch (NormalizeUnitName(strName))
                    {
                        case "Marine":
                            unit = new Marine();
                            break;
                        case "Firebat":
                            unit = new Firebat();
                            break;
                        case "Ghost":
                            unit = new Ghost();
                            break;
                        default:
                            unit = RecruitDefaultUnit();
                            break;
                    }
                    return unit;
                }

                private Unit RecruitDefaultUnit()
                {
                    return (Unit)new Marine();
                }

                private string NormalizeUnitName(string strName)
                {
                    return strName;

                }
                */

        private Dictionary<string, Unit> SampleUnits = new Dictionary<string, Unit>();
        public void InitSampleUnits() // prototype
        {
            SampleUnits.Clear();
            SampleUnits.Add("Marine", new Marine());
            SampleUnits.Add("Firebat", new Firebat());
            SampleUnits.Add("Ghost", new Ghost());
        }

        public Unit RecruitUnit(string strName)
        {
            Unit unit = null;
            string strNormalizedName = NormalizeUnitName(strName);
            if (!SampleUnits.ContainsKey(strNormalizedName))
                strNormalizedName = GetDefaultUnitName();

            return SampleUnits[strNormalizedName].Clone();            
        }

        private string GetDefaultUnitName()
        {
            return "Marine";
        }

        private Unit RecruitDefaultUnit()
        {
            return (Unit)new Marine();
        }

        private string NormalizeUnitName(string strName)
        {
            return strName;
        }



    }
}