﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCreationalPatterns
{
    public class Ghost : Unit
    {
        public Ghost(Ghost marine)
        {

        }

        public override Unit Clone()
        {
            Unit unit = new Ghost(this);
            return unit;

        }

    }
}