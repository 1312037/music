﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    public abstract class Shape
    {
        private static Dictionary<string, Shape> samples = new Dictionary<string, Shape>();

        virtual public void Draw(Graphics g)
        {

        }

        internal static Shape CreateShape(string strOption)
        {
            if (InDictionary(strOption))
                return samples[strOption].Clone();
            return null;
        }

        private static bool InDictionary(string strOption)
        {
            return samples.ContainsKey(strOption);
        }

        public abstract Shape Clone();

        public virtual void WriteToFile(StreamWriter wr)
        {
            
        }

        internal static List<Shape> LoadShapesFromStream(StreamReader sr)
        {
            int n = ReadNumberOfShapesFromStream(sr);
            List<Shape> result = new List<Shape>();
            string strOption;
            for (int i = 0; i < n; i++)
            {
                strOption = sr.ReadLine();
                result.Add(Shape.CreateShape(strOption));
                result[i].LoadFromFile(sr);
            }
            return result;
        }

        protected virtual void LoadFromFile(StreamReader sr)
        {
        }

        private static int ReadNumberOfShapesFromStream(StreamReader sr)
        {
            return 0;
        }
    }
}