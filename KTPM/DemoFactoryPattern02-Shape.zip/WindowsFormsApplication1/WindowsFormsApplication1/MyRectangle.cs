﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    public class MyRectangle : Shape
    {
        public override Shape Clone()
        {
            return null; // dummy
        }
        public override void WriteToFile(StreamWriter wr)
        {
            wr.WriteLine("Rectangle");
        }
    }
}