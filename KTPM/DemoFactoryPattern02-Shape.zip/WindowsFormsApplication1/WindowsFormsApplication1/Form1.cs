﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string strOption = "";

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            strOption = "Rectangle";
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            strOption = "Circle";
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            strOption = "Triangle";
        }

        List<Shape> shapes = new List<Shape>();

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            CreateShapeByName();
        }

        private void CreateShapeByName()
        {
            Shape newShape = null;
            newShape = Shape.CreateShape(strOption);
            shapes.Add(newShape);
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            if (dlg.ShowDialog() != DialogResult.OK)
                return;

            SaveShapesToFile(dlg.FileName);
              
        }

        private void SaveShapesToFile(string fileName)
        {
            StreamWriter wr = new StreamWriter(fileName);
            wr.WriteLine(shapes.Count.ToString());
            for (int i=0; i<shapes.Count;i++)
            {
                shapes[i].WriteToFile(wr);
            }
            wr.Close();



        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() != DialogResult.OK)
                return;

            LoadShapesFromFile(dlg.FileName);

        }

        private void LoadShapesFromFile(string fileName)
        {
            StreamReader sr = new StreamReader(fileName);
            shapes = Shape.LoadShapesFromStream(sr);
            sr.Close();

        }
    }
}
