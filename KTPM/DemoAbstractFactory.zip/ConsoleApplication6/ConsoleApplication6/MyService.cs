﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    public abstract class MyService
    {
        internal OnlineHost Clone()
        {
            throw new NotImplementedException();
        }
    }
}