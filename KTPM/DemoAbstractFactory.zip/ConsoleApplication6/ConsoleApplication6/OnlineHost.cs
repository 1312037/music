﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    public class OnlineHost : MyService
    {
        internal OnlineHost Clone()
        {
            throw new NotImplementedException();
        }
    }
}