﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    public class OnlineHostManager : CloudServiceManager
    {
        Dictionary<string, OnlineHost> samples = new Dictionary<string, OnlineHost>();

        public void InitSamples()
        {
            samples.Add("Tiny Host", new TinyOnlineHost());
            samples.Add("Standard Host", new StandardOnlineHost());
            samples.Add("Processing-oriented Host", new AdvancedOnlineHost());
            samples.Add("Storage-oriented Host", new AdvancedOnlineHost());
        }

        public OnlineHost CreateHost(string strOption)
        {
            if (samples.ContainsKey(strOption))
                return samples[strOption].Clone();
            return null;
        }
    }
}