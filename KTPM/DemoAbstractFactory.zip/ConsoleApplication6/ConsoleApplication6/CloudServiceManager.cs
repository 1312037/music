﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    public abstract class CloudServiceManager
    {
        Dictionary<string, MyService> samples = new Dictionary<string, MyService>();

        abstract public void InitSamples();

        public OnlineHost CreateHost(string strOption)
        {
            if (samples.ContainsKey(strOption))
                return samples[strOption].Clone();
            return null;
        }

    }
}